package com.example.project5;

/**
 * This is the enum class for pizza toppings
 * @author Ryan Pollack, Michael Kang
 */
public enum Topping {
    Chicken,
    Beef,
    Ham,
    Pineapple,
    BlackOlives,
    Cheese,
    Sausage,
    GreenPepper,
    Onion,
    Pepperoni,
    Mushroom
}
