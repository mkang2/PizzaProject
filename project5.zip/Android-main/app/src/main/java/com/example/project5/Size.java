package com.example.project5;

/**
 * This is the enum class for  sizes
 * @author Ryan Pollack, Michael Kang
 */
public enum Size {
    Small,
    Medium,
    Large
}
